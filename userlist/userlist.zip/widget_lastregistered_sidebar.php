<?php
/**
 *¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯*
 *                  Webspell-RM      /                        /   /                                          *
 *                  -----------__---/__---__------__----__---/---/-----__---- _  _ -                         *
 *                   | /| /  /___) /   ) (_ `   /   ) /___) /   / __  /     /  /  /                          *
 *                  _|/_|/__(___ _(___/_(__)___/___/_(___ _/___/_____/_____/__/__/_                          *
 *                               Free Content / Management System                                            *
 *                                           /                                                               *
 *¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯*
 * @version         webspell-rm                                                                              *
 *                                                                                                           *
 * @copyright       2018-2025 by webspell-rm.de                                                              *
 * @support         For Support, Plugins, Templates and the Full Script visit webspell-rm.de                 *
 * @website         <https://www.webspell-rm.de>                                                             *
 * @forum           <https://www.webspell-rm.de/forum.html>                                                  *
 * @wiki            <https://www.webspell-rm.de/wiki.html>                                                   *
 *                                                                                                           *
 *¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯*
 * @license         Script runs under the GNU GENERAL PUBLIC LICENCE                                         *
 *                  It's NOT allowed to remove this copyright-tag                                            *
 *                  <http://www.fsf.org/licensing/licenses/gpl.html>                                         *
 *                                                                                                           *
 *¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯*
 * @author          Code based on WebSPELL Clanpackage (Michael Gruber - webspell.at)                        *
 * @copyright       2005-2011 by webspell.org / webspell.info                                                *
 *                                                                                                           *
 *¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯*
*/

$pm = new plugin_manager(); 
$plugin_language = $pm->plugin_language("userlist", $plugin_path);

$tpl = new Template();
// Daten für das Template "head"
$data_array = [
    'title' => $plugin_language['lastregistered'],
    'subtitle' => 'Userlist'
];

echo $tpl->loadTemplate("userlist","head", $data_array, 'plugin');

// Abrufen der letzten 5 registrierten Benutzer
$result = safe_query("SELECT * FROM users ORDER BY registerdate DESC LIMIT 0,5");

// Template: Header des Widgets ausgeben
echo $tpl->loadTemplate("userlist","widget_lastregistered_head", $data_array, 'plugin');

// Durchlauf durch Benutzerliste
while ($row = mysqli_fetch_array($result)) {
    
    $username = '<a href="index.php?site=profile&amp;id=' . (int)$row['userID'] . '">' . htmlspecialchars($row['username']) . '</a>';

    // Registrierung als DateTime-Objekt
    $register_timestamp = (int)$row['registerdate'];
    $register_date = new DateTime();
    $register_date->setTimestamp($register_timestamp);

    $today = new DateTime();
    $today->setTime(0, 0); // auf Mitternacht setzen

    $interval = (int)$register_date->diff($today)->format('%R%a'); // +/- Tage Differenz

    // Menschlich lesbares Anmeldedatum bestimmen
    if ($interval === 0) {
        $register = $plugin_language['today'];
    } elseif ($interval === -1) {
        $register = $plugin_language['tomorrow'];
    } elseif ($interval > 1) {
        $register = date('d.m.y', $register_timestamp);
    } elseif ($interval === 1) {
        $register = $plugin_language['yesterday'];
    } else {
        $register = date('d.m.y', $register_timestamp);
    }

    // Avatar prüfen
    $avatar = '';
    if ($getavatar = getavatar($row['userID'])) {
        $avatar = './images/avatars/' . htmlspecialchars($getavatar);
    }

    // Benutzer-Daten für Template
    $data_array = [
        'username' => $username,
        'register' => $register,
        'avatar' => $avatar
    ];

    echo $tpl->loadTemplate("userlist","widget_lastregistered_content", $data_array, "plugin");

}

echo $tpl->loadTemplate("userlist","widget_lastregistered_foot", $data_array, "plugin");
?>
