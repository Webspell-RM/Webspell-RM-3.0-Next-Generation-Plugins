<?php
// Botfilter (einfach)
$botAgents = ['bot', 'crawl', 'slurp', 'spider'];
$ua = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');
foreach ($botAgents as $bot) {
    if (strpos($ua, $bot) !== false) return;
}

// Zähle nur einmal pro Session
if (!isset($_SESSION['counted'])) {
    $_SESSION['counted'] = true;

    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $referer = $_SERVER['HTTP_REFERER'] ?? '';
    $page = $_SERVER['REQUEST_URI'] ?? '';
    $timestamp = date('Y-m-d H:i:s');

    safe_query("INSERT INTO plugins_counter (ip, user_agent, referer, timestamp, page)
                VALUES ('$ip', '$user_agent', '$referer', '$timestamp', '$page')");
}