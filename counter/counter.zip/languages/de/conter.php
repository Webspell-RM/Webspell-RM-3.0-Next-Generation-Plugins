<?php

$language_array = array(

	'visits_today' =>"Besuche heute",
'visits_total' => "Gesamtbesuche",
);