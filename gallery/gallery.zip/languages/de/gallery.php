<?php

$language_array = array(

   'gallery' => 'Gallery',
     
    );

